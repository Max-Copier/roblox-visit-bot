                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8                 ooooo     ooo ooooooooo.   ooooooo  ooooo
                 `888'     `8' `888   `Y88.  `8888    d8'
                  888       8   888   .d8